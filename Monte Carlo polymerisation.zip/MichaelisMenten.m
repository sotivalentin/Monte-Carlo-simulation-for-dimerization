
function dydt=MichaelisMenten(t,y,kat,K,elojel, e0, varargin)

% elojel defines if it is decreasing or increasing
%write out the no of arguments
nargin;
%if there are 7 arguments enzyme amount is defined, if 6 it is incorporated
%in kat
switch nargin
    case 7
        v = elojel*kat*e0*(y/(K+y));
    case 6
        v = elojel*kat*e0*(y/(K+y));   
    otherwise
        return;
end
dydt =    v   ;
end


