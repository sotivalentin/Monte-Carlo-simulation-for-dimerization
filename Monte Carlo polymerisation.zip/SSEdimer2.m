function F=SSEdimer2(x,datafile,e)



%the optimised parameter values
kat=x(1);
K=x(2);
SSEsz=[];
for szamlalo2=1:length(datafile)
actualdatafile=datafile{szamlalo2};
tspan=actualdatafile(:,1);
y0=actualdatafile(1,2);
e0=e(szamlalo2);
%dbstop MichaelisMenten
[t1, y1]=ode23s(@(t,y)MichaelisMenten(t,y,kat,K,-1,e0),tspan,y0, foptions);

    SSEsz=vertcat(SSEsz,actualdatafile(:,2)-y1(:));

clear y1 t1
end

F=SSEsz;
