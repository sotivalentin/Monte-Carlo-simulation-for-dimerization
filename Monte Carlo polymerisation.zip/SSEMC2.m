

function F=SSEMC2(x,m0,e_sim,K,Vmax,datafile,datafiledimer,datafiledimer2,step,modeledvanillin)


%the optimised parameter values
k=horzcat(x(3:4),[8 8 8 8],x(5:6));
k=10.^k;
SSEsz=0;
for i=2:length(datafile);
a=datafiledimer2{i};
b=datafiledimer{i};
c=modeledvanillin{i};
%dbstop MonteCarlo
    [savedata, reactions]=MonteCarlo(k,m0,e_sim,K,Vmax,x(2),x(1),i,step,modeledvanillin);

    SSEsz=vertcat(SSEsz,(b(:,2)-transpose(savedata(4,ismember(c(:,1),b(:,1))))),(a(:,2)-transpose(savedata(7,ismember(c(:,1),a(:,1))))));
clear savedata a b c 

end

F=[SSEsz];
