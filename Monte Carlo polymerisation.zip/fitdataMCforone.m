clear all
close all
 
%
%%%% dimer mass 65 (47?) times more than vanillin, based on MS measurements

%%
%input values
%%step of iteration
step=0.001;

% check folder for excel files
names=dir('*.xlsx');

%%
%read in data monomer, e0, m0
for i=2:length(names)
    %%Read in file
a=xlsread(names(i).name);
b=[a(:,6) a(:,5)];
c=[a(:,9) a(:,8)];    
    
        %%Read in enzyme amount and starting dimer conc
    e(i)=a(1,3);
    activity(i)=a(2,3);
    activity2(i)=a(3,3);
    m0(i)=a(1,2);
   

    %read in only real values
datafile{i}=[a(~isnan(a(:,1)),1) a(~isnan(a(:,2)),2)];
datafiledimer{i}=[b(~isnan(b(:,1)),1) b(~isnan(b(:,2)),2)];
datafiledimer2{i}=[c(~isnan(c(:,1)),1) c(~isnan(c(:,2)),2)];

end
clear a b c k j i delete

%%
%%Michaelis constants optimization
%%%fits Michaelis Menten on Monomer concentrations
%%Three parameter, Km Vmax and E amount
%fit enzyme amount
%xk=ones(1,length(datafile)-2);
x0=[0.6 3];
%lb=[0 0 xk*0];
%ub=[10 10000 xk*100];
%dbstop SSEwithalldata
options=optimset('Display','iter','MaxFunEvals',200000,'Tolfun',1e-14,'Maxiter',30000);
[x,resnorm,~,~,~,~,jacobian]=lsqnonlin(@(x)SSEwithalldata(x,datafile,m0,e),x0);
sigmaMonomer=sqrt(resnorm*diag(full((jacobian'*jacobian)^-1)));
%%Vmax and k fitted individually
Vmax=x(1);
K=x(2);
e_sim=e;



%simulation decrease at every point where there are data
figure(1);
set(gcf,'name','MM','numbertitle','off');
for szamlalo=2:length(datafile)
%every point where is dimer data
    uniontimepoints=union(datafiledimer{szamlalo}(:,1),datafiledimer2{szamlalo}(:,1));
%every point where is monomer data
    uniontimepoints=union(uniontimepoints,datafile{szamlalo}(:,1));
[modeledvanillin{szamlalo}(:,1), modeledvanillin{szamlalo}(:,2)]=ode23s(@(t,y)MichaelisMenten(t,y,Vmax,K,-1,e_sim(szamlalo)),uniontimepoints,m0(szamlalo),foptions);
subplot(4,4,szamlalo);
plot(datafile{szamlalo}(:,1),datafile{szamlalo}(:,2),modeledvanillin{szamlalo}(:,1),modeledvanillin{szamlalo}(:,2));
ylim([0 1.2])
end
tightfig(gcf);

clear szamlalo uniontimepoints
%%
%Plot measurement data
figure(2);
set(gcf,'name','Measured data','numbertitle','off');
for szamlalo=2:length(datafile)
    subplot(4,4,szamlalo);
plot(datafile{szamlalo}(:,1),datafile{szamlalo}(:,2),datafiledimer{szamlalo}(:,1),2*datafiledimer{szamlalo}(:,2),datafiledimer2{szamlalo}(:,1),2*datafiledimer2{szamlalo}(:,2), 'LineStyle','none','Marker','x');
ylim([0 1.2])

end
tightfig(gcf);


%%
%%Calculating MM parameters for dimer2
%%only for 10 and 12
datafiledimer2MM{1}=datafiledimer2{14}(6:end,1:2);
datafiledimer2MM{2}=datafiledimer2{11}(6:end,1:2);
ed(1)=e_sim(14);
ed(2)=e_sim(11);

x0=[0.6 3];
lb=[0 0];
ub=[10 10000];

%dbstop SSEdimer2
%dbstop MichaelisMenten
options=optimset('Display','iter','MaxFunEvals',200000,'Tolfun',1e-14,'Maxiter',30000);
[x,resnorm,~,~,~,~,jacobian]=lsqnonlin(@(x)SSEdimer2(x,datafiledimer2MM,ed),x0,lb,ub,options);
sigmaDimer=sqrt(resnorm*diag(full((jacobian'*jacobian)^-1)));
Vmaxdimer=x(1); %1.5936 %0.9766
Kdimer=x(2);     %170 %186

%%plot MM for dimer2
%dbstop MichaelisMenten
figure(3);
set(gcf,'name','MM dimer','numbertitle','off');
for szamlalo=1:2
[time, dimer2]=ode23s(@(t,y)MichaelisMenten(t,y,Vmaxdimer,Kdimer,-1,ed(szamlalo)),datafiledimer2MM{szamlalo}(:,1),datafiledimer2MM{szamlalo}(1,2),foptions);
plot(datafiledimer2MM{szamlalo}(:,1),datafiledimer2MM{szamlalo}(:,2),time,dimer2);
hold on
%ylim([0 1.2])

end
clear szamlalo
%%
%fit MC parameters

%Reaction order
%%MM
%1 M
%2 D2

%%Radical coupling
%Products
%3 2M to D
%4 2M to D2
%Leaving products
%5 M and D 
%6 M and D2
%7 D and D
%8 D and D2
%in the range of 10^5-10^9

%%Radical propagation
%9 M to D
%10 M to D2
%in the range of 10^1-10^4

%% 1 and 2 are important, 3-4 not really, 5-6 medium
%7 and 8 important
lb=[0 0 0 0];
ub=[9 9 4 4];
x0=[5 7 2 2];
%dbstop SSEMC

options=optimset('Display','iter','MaxFunEvals',2000000,'Tolfun',1e-20,'TolX',1e-7,'Maxiter',300000,'DiffMinChange',1);
[x,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@(x)SSEMC(x,m0,e_sim,K,Vmax,Kdimer,Vmaxdimer,datafile,datafiledimer,datafiledimer2,step,modeledvanillin),x0,lb,ub,options);


%%
%Fitting also Kdimer and Vmax dimer the same time
%1 and 2 are important, 3-4 not really, 5-6 medium
%7 and 8 important
lb=[0 0 0 0 0 0];
ub=[5 100 9 9 4 4];
x0=[Vmaxdimer Kdimer x];
%dbstop SSEMC2

options=optimset('Display','iter','MaxFunEvals',2000000,'Tolfun',1e-20,'TolX',1e-7,'Maxiter',300000,'DiffMinChange',1);
[x,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@(x)SSEMC2(x,m0,e_sim,K,Vmax,datafile,datafiledimer,datafiledimer2,step,modeledvanillin),x0,lb,ub,options);

Vmaxdimer=x(1); 
Kdimer=x(2);

sigmaMC=sqrt(resnorm*diag(full((jacobian'*jacobian)^-1)));
%%
%%Simulate Monte Carlo with fitted parameters

k=horzcat(x(3:4),[8 8 8 8],x(5:6));
k=10.^k;
for i=2:length(datafile)
%dbstop MonteCarlo
[savedata{i}, reactions{i} amountjon(i), amountmegy(i)]=MonteCarlo(k,m0,e_sim,K,Vmax,Kdimer,Vmaxdimer,i,step,modeledvanillin);
end

%Plot the modelled concentrations
figure(4);
set(gcf,'name','MC modelled','numbertitle','off');
for i=2:length(datafile)
a=datafile{i};
b=savedata{i};
c=modeledvanillin{i};
subplot(4,4,i);
plot(c(:,1),b(2,:),c(:,1),b(4,:),c(:,1),b(7,:))
ylim([0 1.2])
end
tightfig(gcf);

%Plot reactions histogram
figure(5);
set(gcf,'name','Reaction histograms','numbertitle','off');
for i=2:length(datafile)
    subplot(4,4,i);
    hist(reactions{i}(1:round(length(reactions{i})/20)),1:10)
%ylim([0 1.2])
end
tightfig(gcf);

%%
%Plot measured and modeled
%conc matrix
%M/K+M  M  Mr D Dr D2/D2+K2 D2 D2r 
figure(6);
set(gcf,'name','Measured & Simulated','numbertitle','off');
for i=2:length(datafile)
b=savedata{i};
c=modeledvanillin{i};
subplot(4,4,i);
plot(c(:,1),b(2,:),c(:,1),2*b(4,:),c(:,1),2*b(7,:))
hold on

   a=datafile{i};
   b=datafiledimer{i};
   c=datafiledimer2{i};

   plot(a(:,1),a(:,2), 'LineStyle','none','Marker','x','Color', 'b')
   plot(b(:,1),2*b(:,2), 'LineStyle','none','Marker','o','Color', 'g')
   plot(c(:,1),2*c(:,2), 'LineStyle','none','Marker','o','Color', 'r')
   hold off
ylim([0 1.2])
end
tightfig(gcf);

%%
%plot sum of phenolics

figure(7);
set(gcf,'name','Cumulativ Measured & Simulated','numbertitle','off');
for i=2:length(datafile)
b=savedata{i};
c=modeledvanillin{i};
subplot(4,4,i);
plot(c(:,1),b(2,:),c(:,1),b(2,:)+2*b(4,:),c(:,1),b(2,:)+2*b(4,:)+2*b(7,:))
hold on

   a=datafile{i};
   b=datafiledimer{i};
   c=datafiledimer2{i};

   plot(a(:,1),a(:,2), 'LineStyle','none','Marker','x','Color', 'b')
   plot(b(ismember(a(:,1),b(:,1)),1),a(ismember(a(:,1),b(:,1)),2)+2*b(ismember(a(:,1),b(:,1)),2), 'LineStyle','none','Marker','o','Color', 'g')
   plot(c(:,1),a(ismember(a(:,1),c(:,1)),2)+2*b(ismember(b(:,1),c(:,1)),2)+2*c(:,2), 'LineStyle','none','Marker','o','Color', 'r')
ylim([0 1.2])
   hold off
end
tightfig(gcf);

%Plot the modelled radicals
figure(8);
set(gcf,'name','MC modelled radicals','numbertitle','off');
for i=2:length(datafile)
b=savedata{i};
c=modeledvanillin{i};
subplot(4,4,i);
plot(c(:,1),b(3,:),c(:,1),b(5,:),c(:,1),b(8,:))
%ylim([0 1.2])
end
tightfig(gcf);

figure(9)
plot(e,e_sim,'o')
hold on
line([0 0.1],[0 0.1]);

save osszes.mat K k savedata time modeledvanillin reactions




