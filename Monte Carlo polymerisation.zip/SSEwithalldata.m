function F=SSEwithalldata(x,datafile,m0,e)

kat=x(1);
K=x(2);
e_sim=e;
Residual=[];

for szamlalo=2:length(datafile);
    %vanillin conc
    actualdatafile=cell2mat(datafile(szamlalo));
    %time moments
    tspan=actualdatafile(:,1);
    %starting conc
    y0=m0(szamlalo);
    %simulated enzyme amount
    e0=e_sim(szamlalo); %the others simulated
    %integration of vanillin conc
    [t1, y1]=ode23s(@(t,y)MichaelisMenten(t,y,kat,K,-1,e0),tspan,y0, foptions);
    %Residual matrix
    Residual=vertcat(Residual,actualdatafile(:,2)-y1(:));
    clear y0 y1 t1 tspan actualdatafile
end

F=Residual;
