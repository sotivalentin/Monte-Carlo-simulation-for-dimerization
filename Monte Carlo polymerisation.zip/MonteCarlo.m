%REACTIONS

%Reaction order
%%MM
%1 M
%2 D2

%%Radical coupling
%Products
%3 2M to D
%4 2M to D2
%Leaving products
%5 M and D 
%6 M and D2
%7 D and D
%8 D and D2
%in the range of 10^5-10^9

%%Radical propagation
%9 M to D
%10 M to D2
%in the range of 10^1-10^4

%conc matrix
%M/K+M  M  Mr D Dr D2/D2+K2 D2 D2r 


function [savedata, reactions,amountjon, amountmegy]=MonteCarlo(x,m0,e_sim,K,Vmax,Kdimer,Vmaxdimer,i,step,modeledvanillin)

%set starting vanillin conc
m=m0(i);
e=e_sim(i);
k(3:length(x)+2)=x;
k(1)=Vmax*e; %MM vanillin decrease
k(2)=Vmaxdimer*e; %MM dimer decrease
concmatrix=[1/(m+K) m 0 0 0 1/(0+Kdimer) 0 0]; %values of the initial concentrations
actualisvanillin=modeledvanillin{i}(:,2); %Calculating with modelled, not measured values
reactionszamlalo=1; %how many times the cycle run
szamlalo=1; % actual number of measurement point reached already
amountmegy=0;
amountjon=0;
while concmatrix(2)>0.9*actualisvanillin(end) %calculating longer than the last measured vanillin value
    
    %which compounds decrease with the reaction
                  %1      2  3  4 5  6        7  8    
                  %M/K+M  M  Mr D Dr D2/D2+K2 D2 D2r 
reactionmatrix=   [1      1  0  0 0  0        0  0 ;
                   0      0  0  0 0  1        1  0 ;
                   0      0  2  0 0  0        0  0;
                   0      0  2  0 0  0        0  0;
                   0      0  1  0 0  0        0  1;
                   0      0  0  0 2  0        0  0;
                   0      0  0  0 1  0        0  1;
                   0      0  0  0 0  0        0  2;
                   0      0  1  1 0  0        0  0;
                   0      0  1  0 0  0        1  0];
                    
    %which products are formed with the reaction
    productmatrix=[0      0  1  0 0  0        0  0 ;
                   0      0  0  0 0  0        0  1 ;
                   0      0  0  1 0  0        0  0;
                   0      0  0  0 0  0        1  0;
                   0      0  0  0 0  0        0  0;
                   0      0  0  0 0  0        0  0;
                   0      0  0  0 0  0        0  0;
                   0      0  0  0 0  0        0  0;
                   0      1  0  0 1  0        0  0;
                   0      1  0  0 0  0        0  1];
                  
%reaction rates
v=ones(1,10);
for ii=1:10
    for j=1:8
        %for every reaction calculate the conc
   v(ii)=v(ii)*concmatrix(j)^reactionmatrix(ii,j);
    end    
    %multiply with k reaction coefficients
    v(ii)=v(ii)*k(ii);
end
%normailze values
vnorm=v/sum(v);
vnormdense(1)=vnorm(1);
for kk=2:length(vnorm)
vnormdense(kk)=vnormdense(kk-1)+vnorm(kk);%calculate cummulative distributions
end

%choose the reaction (
nagyobbszam=find ( vnormdense>rand (1), 1, 'first');
reactions(reactionszamlalo)=nagyobbszam; % the vector containing which reaction happened
reactionszamlalo=reactionszamlalo+1; %how many reactions happened altogether

%determine the min step (is there enough product?)
min=step;
for ii=1:8
    if reactionmatrix(nagyobbszam,ii)>0
    if concmatrix(ii)/reactionmatrix(nagyobbszam,ii)<min
        min=concmatrix(ii)/reactionmatrix(nagyobbszam,ii);
    end
    end    
end

%new concentrations
for ii=1:8
    %decreasing by reaction
    if reactionmatrix(nagyobbszam,ii)>0
    concmatrix(ii)=concmatrix(ii)-reactionmatrix(nagyobbszam,ii)*min;    
        if (nagyobbszam==2||nagyobbszam==3) && ii==2
            %%monomer decreasing, but not MM reaction
        amountmegy=amountmegy+reactionmatrix(nagyobbszam,ii)*min;
        end
    end
    %% increasing because reaction products
    if productmatrix(nagyobbszam,ii)>0
    concmatrix(ii)=concmatrix(ii)+productmatrix(nagyobbszam,ii)*min;
        if (nagyobbszam==5||nagyobbszam==6) && ii==2
            %Monomer increasing
        amountjon=amountjon+productmatrix(nagyobbszam,ii)*min;
        end
    end
end

%new 1/K+M
concmatrix(1)=1/(K+concmatrix(2));
concmatrix(6)=1/(Kdimer+concmatrix(7));


%Save out data, where we have measurement points
if szamlalo<=length(actualisvanillin)
if concmatrix(2)<actualisvanillin(szamlalo,1) % if monomer decreases under the next measurement point save out

savedata(:,szamlalo)=concmatrix; %save out concentrations
szamlalo=szamlalo+1;
end
end
end
end
